# Installation

Pour installer les dépendances du projet, suivez les étapes ci-dessous.

## Prérequis

    Assurez-vous d'avoir Python 3.12.6 installé. Vous pouvez le télécharger à partir de cette page officielle.

    Ouvrez votre terminal, puis exécutez la commande suivante pour installer les dépendances :